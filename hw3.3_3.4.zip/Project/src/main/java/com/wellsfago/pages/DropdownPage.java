package com.wellsfago.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.List;

public class DropdownPage {

    private WebDriver driver;
    private String value1 = "Cash Back";
    private String value2 = "Rewards";
    private String value3 = "Balance Transfer";
    private String value4 = "Build Credit";
    private String value5 = "No Annual Fee";
    private String value6 = "All Cards*";
    private List<String> expectedValues;

    public DropdownPage(){
        expectedValues = new ArrayList<String>();
        expectedValues.add(value1);
        expectedValues.add(value2);
        expectedValues.add(value3);
        expectedValues.add(value4);
        expectedValues.add(value5);
        expectedValues.add(value6);
    }

    public String getValue1(){
        return expectedValues.get(0);
    }
    public String getValue2(){
        return expectedValues.get(2);
    }
    public String getValue3(){
        return expectedValues.get(3);
    }
    public String getValue4(){
        return expectedValues.get(4);
    }
    public String getValue5(){
        return expectedValues.get(5);
    }
    public String getValue6(){
        return expectedValues.get(6);
    }

    Select select = new Select(driver.findElement(By.id("productCustomMenu")));
    List<WebElement> dropdownValues = select.getOptions();
}
