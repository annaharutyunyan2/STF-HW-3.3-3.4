package com.wellsfago.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class HoverPage {

    private WebDriver driver;
    Actions actions = new Actions(driver);

    WebElement hoverPage1 = driver.findElement(By.xpath("//*[@id=\"fatnav\"]/li[1]"));
    WebElement hoverPage2 = driver.findElement(By.id("loansTab"));
    WebElement hoverPage3 = driver.findElement(By.id("investingTab"));
    WebElement hoverPage4 = driver.findElement(By.id("wealthTab"));
    WebElement hoverPage5 = driver.findElement(By.id("rewardsTab"));

    public HoverPage(WebDriver driver){
        this.driver = driver;
    }

    public void hoverOverPage1(){
        actions.moveToElement(hoverPage1).perform();
    }

    public void hoverOverPage2(){
        actions.moveToElement(hoverPage2).perform();
    }

    public void hoverOverPage3(){
        actions.moveToElement(hoverPage3).perform();
    }

    public void hoverOverPage4(){
        actions.moveToElement(hoverPage4).perform();
    }

    public void hoverOverPage5(){
        actions.moveToElement(hoverPage5).perform();
    }
}
