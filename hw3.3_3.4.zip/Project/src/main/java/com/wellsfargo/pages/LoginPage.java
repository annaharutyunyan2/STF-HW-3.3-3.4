package com.wellsfargo.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {

    private WebDriver driver;

    private By username = By.id("userid");
    private By password = By.name("j_password");
    private By signOnButton = By.xpath("//*[@id=\"btnSignon\"]");
    private By saveUsername = By.className("lsc");

    public LoginPage(WebDriver driver){
        this.driver = driver;
    }

//    public void clickStart() {
//        driver.findElement(username).click();
//        WebDriverWait wait = new WebDriverWait(driver, 5);
//        wait.until(ExpectedConditions.invisibilityOf(driver.findElement(password)));
//    }

    public void writeUsername(String user){
        driver.findElement(username).sendKeys(user);
    }

    public void writePassword(String pass){
        driver.findElement(password).sendKeys(pass);
    }

    public void clickSignOnButton(){
        driver.findElement(signOnButton).click();
    }

    public void clickSaveUsernameButton(){
        driver.findElement(saveUsername).click();
    }
}
