package com.wellsfargo.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SearchBarPage {
    private WebDriver driver;

    private By searchBar = By.id("nxgSearchButton");
    private By searchInputBox = By.xpath("//*[@id=\"app-modal-root\"]/div/div/div/div/div/div/div/div[1]/div/div/form/div[1]");
    private By searchButton = By.className("SearchButton__searchButton___318vg");

    public SearchBarPage(WebDriver driver) {
        this.driver = driver;
    }
    public void clickSearchBar(){
        driver.findElement(searchBar).click();
    }
    public void writeSearch(String search){
        driver.findElement(searchInputBox).sendKeys(search);
    }
    public void clickSearchButton(){
        driver.findElement(searchButton).click();
    }
}
