package com.wellsFargo.tests;

import com.wellsfargo.pages.DropdownPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


import java.util.List;

public class DropdownTest {

    public static void main(String[] args){

        System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.wellsfargo.com/credit-cards/find-a-credit-card/cash-back/");

        Select select = new Select(driver.findElement(By.id("productCustomMenu")));
        List<WebElement> dropdownValues = select.getOptions();
        System.out.println(dropdownValues.size());
        DropdownPage dropdownPage = new DropdownPage();
//        List<String> expectedValues = dropdownPage.getList();

//        for(int i = 0; i < dropdownValues.size(); i++){
//            Assert.assertEquals(dropdownValues.get(i).getText());
//        }
//        System.out.println("It matches");
//        driver.close();
        if(dropdownPage.getValue1() == dropdownValues.get(0).getText() &&
                dropdownPage.getValue2() == dropdownValues.get(1).getText() &&
                dropdownPage.getValue3() == dropdownValues.get(2).getText() &&
                dropdownPage.getValue4() == dropdownValues.get(3).getText() &&
                dropdownPage.getValue5() == dropdownValues.get(4).getText() &&
                dropdownPage.getValue6() == dropdownValues.get(5).getText()){
            System.out.println("Everything matches");
        }else{
            System.out.println("It doesn't match");
        }
    }
}
