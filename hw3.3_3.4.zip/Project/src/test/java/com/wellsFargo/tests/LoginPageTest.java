package com.wellsFargo.tests;

import com.utilities.ScreenshotFunctionality;
import com.wellsfargo.pages.LoginPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class LoginPageTest {

    @Test
    public void validLogin() throws Exception{
        System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.wellsfargo.com/");

        LoginPage login = new LoginPage(driver);
        login.writeUsername("username");
        ScreenshotFunctionality.takeScreenshot(driver, "screenshot 1");
        login.writePassword("password");
        login.clickSaveUsernameButton();
        login.clickSignOnButton();
        driver.quit();
    }

}
