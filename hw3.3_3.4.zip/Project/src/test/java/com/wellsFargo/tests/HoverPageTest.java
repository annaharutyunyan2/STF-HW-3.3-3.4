package com.wellsFargo.tests;

import com.wellsfago.pages.HoverPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import static org.openqa.selenium.support.ui.ExpectedConditions.visibilityOf;

public class HoverPageTest {
    @Test
    public void hoverPageTest1 (){
        System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.wellsfargo.com/");

        HoverPage hover = new HoverPage(driver);
        visibilityOf(driver.findElement(By.xpath("//*[@id=\"fatnav\"]/li[1]")));
    }
}
