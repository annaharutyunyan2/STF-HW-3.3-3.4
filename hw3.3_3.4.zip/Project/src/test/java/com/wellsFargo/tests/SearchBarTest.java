package com.wellsFargo.tests;

import com.wellsfargo.pages.LoginPage;
import com.wellsfargo.pages.SearchBarPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class SearchBarTest {
    @Test
    public void searching(){
        System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.wellsfargo.com/");

        SearchBarPage searching = new SearchBarPage(driver);
        searching.clickSearchBar();
    }
}
